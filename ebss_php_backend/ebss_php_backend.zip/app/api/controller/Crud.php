<?php
namespace app\api\controller;
use app\Basic;
use app\Logined;
use \think\facade\Db;
class Crud extends \app\admin\controller\Crud
{
}
