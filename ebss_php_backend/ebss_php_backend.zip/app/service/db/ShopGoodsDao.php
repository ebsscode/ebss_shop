<?php

namespace app\service\db;

class ShopGoodsDao
{

}