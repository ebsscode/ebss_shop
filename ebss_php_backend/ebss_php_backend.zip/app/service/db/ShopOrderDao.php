<?php

namespace app\service\db;

class ShopOrderDao
{

}