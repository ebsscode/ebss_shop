<?php

namespace app\service\system;

class TimeService
{
    public static function todayDate(){
        return date('Y-m-d');
    }


}