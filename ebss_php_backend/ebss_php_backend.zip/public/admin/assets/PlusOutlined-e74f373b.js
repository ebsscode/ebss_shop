import{P as f}from"./index-5116e4ca.js";export{f as default};
