import{_ as e,o as t,c as o}from"./index-eba80501.js";const a={name:"detail"};function c(n,r,s,_,p,d){return t(),o("div")}const f=e(a,[["render",c]]);export{f as default};
